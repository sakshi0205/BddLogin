package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	
	WebDriver driver=new ChromeDriver();
	
	
	
	
	@Given("^User is on Home Page$")
	public void user_is_on_Home_Page()   {
		System.setProperty("webdriver.chrome.driver", "C:/Users/sakraut/Desktop/libs/chromedriver.exe");
		driver=new ChromeDriver();
	    driver.navigate().to("http://demowebshop.tricentis.com");
	}

	@When("^User Navigate to LogIn Page$")
	public void user_Navigate_to_LogIn_Page()   {
		System.setProperty("webdriver.chrome.driver", "C:/Users/sakraut/Desktop/libs/chromedriver.exe");
		    driver=new ChromeDriver();
		   driver.findElement(By.linkText("Log in")).click();
	}

	@When("^User enters Email and Password$")
	public void user_enters_Email_and_Password()   {
		System.setProperty("webdriver.chrome.driver", "C:/Users/sakraut/Desktop/libs/chromedriver.exe");
		 driver=new ChromeDriver();
		  driver.findElement(By.name("Email")).sendKeys("sakshi123@gmail.com");
		     driver.findElement(By.name("Password")).sendKeys("sakshi");
	}

	@Then("^Message displayed Successfull login$")
	public void message_displayed_Successfull_login()   {
		System.setProperty("webdriver.chrome.driver", "C:/Users/sakraut/Desktop/libs/chromedriver.exe");
		 driver=new ChromeDriver();
		  driver.findElement(By.xpath("//input[@value='Log in']")).click();
		  System.out.println("Login Successfully");
	}


}
